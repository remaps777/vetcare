@extends('layouts.guest')
@section('title', 'Bienvenido')
@section('content')
<div class="text-center">
    <span class="brand-badge mb-3"><i class="bi bi-heart-pulse"></i> Cuidamos de quienes amas</span>
    <h1 class="h3 fw-bold mb-3">El cuidado de tu mascota, en un solo lugar</h1>
    <p class="text-muted mb-4">Accede a tu cuenta para consultar tus mascotas, citas e historial de atención veterinaria.</p>
    <div class="d-grid gap-2">
        <a href="{{ route('login') }}" class="btn btn-primary btn-lg">Iniciar sesión</a>
        <a href="{{ route('register.owner') }}" class="btn btn-outline-primary">Registrarme como propietario</a>
        <a href="{{ route('register.doctor') }}" class="btn btn-link text-secondary">Soy médico veterinario</a>
    </div>
</div>
@endsection
