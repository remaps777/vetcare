@extends('layouts.app')
@section('title', 'Usuarios')
@section('page-title', 'Administración de usuarios')
@section('content')
<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div><h5 class="mb-1">Usuarios</h5><p class="text-muted mb-0">Administra datos, perfiles y permisos desde esta pantalla.</p></div>
            <div class="input-group" style="max-width: 320px"><span class="input-group-text"><i class="bi bi-search"></i></span><input class="form-control" data-user-search placeholder="Buscar usuario..."></div>
        </div>
        <div class="table-responsive">
            <table class="table align-middle" data-users-table>
                <thead><tr><th>Nombre</th><th>Correo</th><th>Tipo inicial</th><th>Perfil</th><th>Estado</th><th class="text-end">Acciones</th></tr></thead>
                <tbody>
                @foreach($users as $user)
                    <tr data-user-row data-search="{{ strtolower($user->name.' '.$user->email.' '.$user->profile?->name) }}">
                        <td>{{ $user->name }}</td><td>{{ $user->email }}</td>
                        <td>{{ $user->account_type === 'DOCTOR' ? 'Doctor' : 'Usuario' }}</td>
                        <td>{{ $user->profile?->name ?? 'Sin perfil' }}</td>
                        <td><span class="badge text-bg-{{ $user->is_active ? 'success' : 'secondary' }}">{{ $user->is_active ? 'Activo' : 'Inactivo' }}</span></td>
                        <td class="text-end">
                            <div class="d-flex justify-content-end gap-1">
                                    @if(auth()->user()->hasPermission('usuarios.editar'))
                                        <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editUserModal" data-bs-title="Editar datos" title="Editar datos" aria-label="Editar datos" data-user-name="{{ $user->name }}" data-user-email="{{ $user->email }}" data-user-update="{{ route('admin.users.update', ['user' => $user->getRouteKey()]) }}"><i class="bi bi-pencil"></i></button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#profileUserModal" data-bs-title="Cambiar perfil" title="Cambiar perfil" aria-label="Cambiar perfil" data-user-name="{{ $user->name }}" data-user-profile="{{ $user->profile?->name ?? 'Sin perfil' }}" data-profile-action="{{ route('admin.users.profile.update', ['user' => $user->getRouteKey()]) }}"><i class="bi bi-person-badge"></i></button>
                                        <button type="button" class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#toggleUserModal" data-bs-title="{{ $user->is_active ? 'Desactivar' : 'Activar' }}" title="{{ $user->is_active ? 'Desactivar' : 'Activar' }}" aria-label="{{ $user->is_active ? 'Desactivar' : 'Activar' }}" data-user-name="{{ $user->name }}" data-user-active="{{ $user->is_active ? '1' : '0' }}" data-toggle-action="{{ route('admin.users.toggle', ['user' => $user->getRouteKey()]) }}"><i class="bi bi-toggle-{{ $user->is_active ? 'on' : 'off' }}"></i></button>
                                    @endif
                                    @if(auth()->user()->hasPermission('usuarios.cambiar_permisos'))
                                        <button type="button" class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#permissionsUserModal" data-bs-title="Configurar permisos" title="Configurar permisos" aria-label="Configurar permisos" data-user-name="{{ $user->name }}" data-permissions-url="{{ route('admin.users.permissions.data', ['user' => $user->getRouteKey()]) }}" data-permissions-save="{{ route('admin.users.permissions.sync', ['user' => $user->getRouteKey()]) }}"><i class="bi bi-shield-lock"></i></button>
                                    @endif
                                    @if(auth()->user()->hasPermission('usuarios.restaurar_password'))
                                        <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#passwordUserModal" data-bs-title="Restaurar contraseña" title="Restaurar contraseña" aria-label="Restaurar contraseña" data-user-name="{{ $user->name }}" data-password-action="{{ route('admin.users.restore-password', ['user' => $user->getRouteKey()]) }}"><i class="bi bi-key"></i></button>
                                    @endif
                            </div>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        {{ $users->links() }}
    </div>
</div>

@include('admin.users.modals')
@endsection
