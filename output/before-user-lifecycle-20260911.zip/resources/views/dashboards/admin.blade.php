@extends('layouts.app')
@section('title', 'Dashboard administrativo')
@section('page-title', 'Dashboard')
@section('content')
<div class="mb-4"><h1 class="h3 fw-bold">Resumen de la clínica</h1><p class="text-secondary">Bienvenido, {{ auth()->user()->name }}. Consulta la actividad y las solicitudes de registro.</p></div>
@include('partials.stats', ['icons' => ['people', 'person-badge', 'hourglass-split', 'heart', 'calendar-event']])
<section class="vet-card p-4">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
        <div><h2 class="h5 fw-bold">Solicitudes de doctores</h2><p class="text-secondary mb-0">Revisa los datos profesionales antes de habilitar el acceso a la clínica.</p></div>
    </div>
    @if($pendingDoctors->isEmpty())
        <p class="text-secondary mb-0 mt-3">No hay solicitudes pendientes.</p>
    @else
        <div class="table-responsive mt-3"><table class="table align-middle mb-0" data-datatable>
            <thead><tr><th>Doctor</th><th>DNI / Colegiatura</th><th>Especialidad</th><th>Acciones</th></tr></thead>
            <tbody>@foreach($pendingDoctors as $doctor)
                <tr>
                    <td>{{ $doctor->user->name }}<div class="small text-secondary">{{ $doctor->user->email }}</div></td>
                    <td>{{ $doctor->dni }}<div class="small text-secondary">{{ $doctor->license_number }}</div></td>
                    <td>{{ $doctor->specialty?->name ?? ($doctor->specialty ?: '—') }}</td>
                    <td class="text-nowrap">
                        <form class="d-inline" method="POST" action="{{ route('admin.doctors.approve', $doctor) }}">@csrf @method('PATCH')<button class="btn btn-sm btn-success">Aprobar</button></form>
                        <form class="d-inline" method="POST" action="{{ route('admin.doctors.reject', $doctor) }}">@csrf @method('PATCH')<button class="btn btn-sm btn-outline-danger">Rechazar</button></form>
                    </td>
                </tr>
            @endforeach</tbody>
        </table></div>
    @endif
</section>
@endsection
