@extends('layouts.app')
@section('title', $title)
@section('page-title', $title)
@section('content')
@php
    $statusLabels = [
        'PENDING' => 'Pendiente',
        'CONFIRMED' => 'Confirmada',
        'COMPLETED' => 'Atendida',
        'CANCELLED' => 'Cancelada',
    ];
@endphp
<div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
    <div><h1 class="h3 fw-bold">{{ $title }}</h1><p class="text-secondary mb-0">{{ $description }}</p></div>
    @if($canCreate)<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createRecord"><i class="bi bi-plus-lg me-2"></i>Nuevo registro</button>@endif
</div>
<div class="vet-card p-3 p-md-4">
    @if($records->isEmpty())<p class="text-secondary text-center py-4 mb-0">No hay registros disponibles.</p>
    @else
        <div class="table-responsive"><table class="table align-middle mb-3" data-datatable>
            <thead><tr>@foreach($columns as $label)<th scope="col">{{ $label }}</th>@endforeach @if($canEdit || $canDelete || ($canUpdateStatus ?? false))<th scope="col">Acciones</th>@endif</tr></thead>
            <tbody>@foreach($records as $record)<tr>
                @foreach($columns as $key => $label)
                    @php $value = data_get($record, $key); @endphp
                    <td>@if($value instanceof \DateTimeInterface) {{ $value->format('d/m/Y H:i') }} @elseif(is_bool($value)) <span class="badge {{ $value ? 'text-bg-success' : 'text-bg-secondary' }}">{{ $value ? 'Sí' : 'No' }}</span> @elseif($key === 'status') <span class="badge text-bg-light border">{{ $statusLabels[$value] ?? $value ?? '—' }}</span> @else {{ $value ?? '—' }} @endif</td>
                @endforeach
                @if($canEdit || $canDelete || ($canUpdateStatus ?? false))<td class="text-nowrap">
                    @if($canEdit)<button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editRecord{{ $record->id }}">Editar</button>@endif
                    @if($canDelete)<button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteRecord{{ $record->id }}">Eliminar</button>@endif
                    @if(($canUpdateStatus ?? false) && isset($record->status))
                        <form method="POST" action="{{ route($base.'.status', ['record' => $record->id]) }}" class="d-inline-flex align-items-center gap-1">
                            @csrf
                            @method('PATCH')
                            <label class="visually-hidden" for="status-{{ $record->id }}">Estado de la cita</label>
                            <select class="form-select form-select-sm" id="status-{{ $record->id }}" name="status" onchange="this.form.submit()">
                                @foreach(['PENDING' => 'Pendiente', 'CONFIRMED' => 'Confirmada', 'COMPLETED' => 'Atendida', 'CANCELLED' => 'Cancelada'] as $status => $label)
                                    <option value="{{ $status }}" @selected($record->status === $status)>{{ $label }}</option>
                                @endforeach
                            </select>
                        </form>
                    @endif
                </td>@endif
            </tr>@endforeach</tbody>
        </table></div>
        {{ $records->links('pagination::bootstrap-5') }}
    @endif
</div>
@if($canCreate) @include('modules.form', ['record' => null, 'modalId' => 'createRecord']) @endif
@if($canEdit) @foreach($records as $record) @include('modules.form', ['modalId' => 'editRecord'.$record->id]) @endforeach @endif
@if($canDelete) @foreach($records as $record)
    <div class="modal fade" id="deleteRecord{{ $record->id }}" tabindex="-1" aria-labelledby="deleteRecord{{ $record->id }}Title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered"><div class="modal-content">
            <form data-confirmed-form method="POST" action="{{ route($base.'.destroy', [...($routeParams ?? []), 'record' => $record->id]) }}">
                @csrf
                @method('DELETE')
                <input type="hidden" name="_version" value="{{ \App\Services\RecordVersion::of($record) }}">
                <div class="modal-header"><h2 class="modal-title fs-5" id="deleteRecord{{ $record->id }}Title">Eliminar registro</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button></div>
                <div class="modal-body"><div class="alert alert-danger d-none" data-form-errors role="alert"></div><p>¿Deseas eliminar <strong>{{ $record->name }}</strong>? Esta acción no se puede realizar si tiene citas o consultas relacionadas.</p><div class="d-none" data-edit-fields></div><div class="d-none" data-confirmation><p class="fw-semibold">Confirma la eliminación</p><dl class="row mb-0" data-summary></dl></div></div>
                <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-back-to-edit>Volver</button><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button><button type="submit" class="btn btn-danger" data-save-button>Revisar y eliminar</button></div>
            </form>
        </div></div>
    </div>
@endforeach @endif
@endsection
