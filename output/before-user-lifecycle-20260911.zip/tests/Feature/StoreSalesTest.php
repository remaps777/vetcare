<?php

namespace Tests\Feature;

use App\Models\Product;
use App\Models\Profile;
use App\Models\User;
use App\Models\Warehouse;
use App\Services\InventoryService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class StoreSalesTest extends TestCase
{
    use RefreshDatabase;

    public function test_showcase_only_lists_products_with_store_stock(): void
    {
        $user = $this->cashier();
        $product = $this->product();
        $this->actingAs($user)->get('/store/showcase')->assertOk()->assertDontSee($product->name);

        app(InventoryService::class)->registerEntry(Warehouse::where('code', 'CLINIC')->firstOrFail(), 'product', $product->id, 5, 'Ingreso clínica', $user);
        $this->actingAs($user)->get('/store/showcase')->assertOk()->assertDontSee($product->name);
        app(InventoryService::class)->registerEntry(Warehouse::where('code', 'STORE')->firstOrFail(), 'product', $product->id, 2, 'Reposición tienda', $user);
        $this->actingAs($user)->get('/store/showcase')->assertOk()->assertSee($product->name);
    }

    public function test_sale_uses_store_stock_and_keeps_clinic_stock_unchanged(): void
    {
        $user = $this->cashier();
        $product = $this->product();
        $service = app(InventoryService::class);
        $clinic = Warehouse::where('code', 'CLINIC')->firstOrFail();
        $store = Warehouse::where('code', 'STORE')->firstOrFail();
        $service->registerEntry($clinic, 'product', $product->id, 20, 'Ingreso clínica', $user);
        $service->registerEntry($store, 'product', $product->id, 4, 'Reposición tienda', $user);

        $this->actingAs($user)->post('/store/sales', [
            'items' => [['product_id' => $product->id, 'quantity' => 2]],
        ])->assertRedirect();

        $this->assertSame(20, $service->getStock($clinic, 'product', $product->id));
        $this->assertSame(2, $service->getStock($store, 'product', $product->id));
        $this->assertDatabaseHas('sales', ['seller_user_id' => $user->id, 'total_cents' => 2000]);
    }

    public function test_sale_rolls_back_when_one_item_has_insufficient_store_stock(): void
    {
        $user = $this->cashier();
        $first = $this->product('A');
        $second = $this->product('B');
        $store = Warehouse::where('code', 'STORE')->firstOrFail();
        app(InventoryService::class)->registerEntry($store, 'product', $first->id, 2, 'Reposición', $user);

        $this->actingAs($user)->post('/store/sales', [
            'items' => [
                ['product_id' => $first->id, 'quantity' => 1],
                ['product_id' => $second->id, 'quantity' => 1],
            ],
        ])->assertSessionHasErrors('items');

        $this->assertDatabaseCount('sales', 0);
        $this->assertSame(2, app(InventoryService::class)->getStock($store, 'product', $first->id));
    }

    private function cashier(): User
    {
        $user = User::factory()->create(['role' => User::ROLE_OWNER]);
        $user->update(['profile_id' => Profile::where('code', 'CAJA')->value('id')]);

        return $user->fresh();
    }

    private function product(string $suffix = ''): Product
    {
        return Product::create([
            'code' => 'PRO-'.($suffix ?: fake()->unique()->numerify('####')),
            'name' => 'Producto '.$suffix.fake()->unique()->numerify('###'),
            'type' => 'Higiene',
            'presentation' => 'Unidad',
            'sale_price_cents' => 1000,
            'minimum_stock' => 1,
            'is_active' => true,
        ]);
    }
}
