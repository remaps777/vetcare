<?php

namespace App\Services;

use App\Models\AuditLog;
use App\Models\Profile;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use RuntimeException;

class UserService
{
    public function update(User $target, array $data, User $actor): User
    {
        $before = $target->only(['name', 'email', 'is_active', 'profile_id']);
        $target->fill($data)->save();
        $this->audit($actor, $target, 'USER_UPDATED', $before, $target->only(['name', 'email', 'is_active', 'profile_id']));

        return $target;
    }

    public function assignProfile(User $target, Profile $profile, User $actor): User
    {
        if ($target->profile_id === $profile->id) {
            return $target;
        }

        $this->guardLastAdministrator($target, $profile->code);
        $before = ['profile_id' => $target->profile_id, 'profile' => $target->profile?->code];
        $target->profile()->associate($profile)->save();
        $this->audit($actor, $target, 'USER_PROFILE_CHANGED', $before, ['profile_id' => $profile->id, 'profile' => $profile->code]);

        return $target;
    }

    public function activate(User $target, User $actor): User
    {
        $target->update(['is_active' => true]);
        $this->audit($actor, $target, 'USER_ACTIVATED', ['is_active' => false], ['is_active' => true]);

        return $target;
    }

    public function deactivate(User $target, User $actor): User
    {
        if ($target->id === $actor->id || $this->isLastEffectiveAdministrator($target)) {
            throw new RuntimeException('No puedes desactivar al último administrador efectivo.');
        }

        $target->update(['is_active' => false]);
        $this->audit($actor, $target, 'USER_DEACTIVATED', ['is_active' => true], ['is_active' => false]);

        return $target;
    }

    public function restorePassword(User $target, User $actor): string
    {
        $temporaryPassword = Str::password(16);
        $target->update(['password' => Hash::make($temporaryPassword)]);
        $this->audit($actor, $target, 'USER_PASSWORD_RESET', [], ['reset' => true]);

        return $temporaryPassword;
    }

    private function guardLastAdministrator(User $target, string $newProfile): void
    {
        if ($target->profile?->code !== 'ADMINISTRADOR' || $newProfile === 'ADMINISTRADOR') {
            return;
        }

        if ($this->isLastEffectiveAdministrator($target)) {
            throw new RuntimeException('No puedes cambiar el perfil del último administrador efectivo.');
        }
    }

    private function isLastEffectiveAdministrator(User $target): bool
    {
        return User::query()->where('is_active', true)->get()
            ->filter(fn (User $user): bool => $user->hasPermission('usuarios.ver') && $user->hasPermission('usuarios.cambiar_permisos'))
            ->count() === 1 && $target->hasPermission('usuarios.ver') && $target->hasPermission('usuarios.cambiar_permisos');
    }

    private function audit(User $actor, User $target, string $action, array $before, array $after): void
    {
        AuditLog::create([
            'user_id' => $actor->id,
            'action' => $action,
            'subject_type' => User::class,
            'subject_id' => $target->id,
            'before_data' => $before,
            'after_data' => $after,
        ]);
    }
}
