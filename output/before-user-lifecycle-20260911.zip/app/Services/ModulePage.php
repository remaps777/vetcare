<?php

namespace App\Services;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Contracts\View\View;

class ModulePage
{
    /**
     * @param  array<string,mixed>  $fields
     * @param  array<string,string>  $columns
     * @param  array<string,mixed>  $routeParams  Extra route parameters (e.g. ['catalog' => 'species'])
     */
    public static function render(
        string $title,
        LengthAwarePaginator $records,
        array $fields,
        array $columns,
        string $base,
        bool $canCreate = true,
        bool $canEdit = true,
        bool $sensitive = true,
        string $description = '',
        array $routeParams = [],
        ?array $formFields = null,
        bool $canDelete = false,
        bool $canUpdateStatus = false,
    ): View {
        $formFields ??= $fields;

        return view('modules.index', ['title' => $title, 'records' => $records, 'fields' => $formFields, 'columns' => $columns, 'base' => $base, 'canCreate' => $canCreate, 'canEdit' => $canEdit, 'canDelete' => $canDelete, 'canUpdateStatus' => $canUpdateStatus, 'sensitive' => $sensitive, 'description' => $description, 'routeParams' => $routeParams]);
    }
}
