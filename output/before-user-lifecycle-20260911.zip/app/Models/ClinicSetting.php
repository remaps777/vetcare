<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClinicSetting extends Model
{
    protected $fillable = ['name', 'phone', 'email', 'address', 'appointment_minutes'];
}
