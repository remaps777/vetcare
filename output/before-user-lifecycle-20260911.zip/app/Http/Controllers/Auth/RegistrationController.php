<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\RegistrationRequest;
use App\Models\DoctorProfile;
use App\Models\Profile;
use App\Models\Specialty;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;

class RegistrationController extends Controller
{
    public function store(RegistrationRequest $request): RedirectResponse
    {
        $doctor = $request->routeIs('register.doctor.store');
        $data = $request->validated();

        DB::transaction(function () use ($data, $doctor): void {
            $user = new User([
                'name' => $data['first_name'].' '.$data['last_name'],
                'username' => $data['username'],
                'email' => $data['email'],
                'password' => $data['password'],
            ]);
            $user->role = $doctor ? User::ROLE_DOCTOR : User::ROLE_OWNER;
            $user->account_type = $doctor ? User::ACCOUNT_TYPE_DOCTOR : User::ACCOUNT_TYPE_USER;
            $user->profile_id = Profile::where('code', $doctor ? 'DOCTOR' : 'PROPIETARIO')->value('id');
            $user->is_active = ! $doctor;
            $user->save();

            if ($doctor) {
                $specialty = Specialty::query()->whereKey($data['specialty_id'])->where('is_active', true)->firstOrFail();

                $profile = $user->doctorProfile()->make([
                    'dni' => $data['dni'],
                    'license_number' => $data['license_number'],
                    'specialty_id' => $specialty->id,
                    'specialty' => $specialty->name,
                    'phone' => $data['phone'],
                ]);
                $profile->approval_status = DoctorProfile::STATUS_PENDING;
                $profile->save();
            } else {
                $user->owner()->create([
                    'first_name' => $data['first_name'],
                    'last_name' => $data['last_name'],
                    'dni' => $data['dni'],
                    'phone' => $data['phone'],
                    'email' => $data['email'],
                    'address' => $data['address'] ?? null,
                    'is_active' => true,
                ]);
            }
        });

        return redirect()->route('login')->with(
            $doctor ? 'warning' : 'success',
            $doctor ? 'Solicitud registrada. Tu cuenta está pendiente de aprobación por un administrador.' : 'Tu cuenta de propietario está lista. Ya puedes iniciar sesión.',
        );
    }
}
