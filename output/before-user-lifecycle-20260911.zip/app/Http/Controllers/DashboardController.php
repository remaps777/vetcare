<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Consultation;
use App\Models\DoctorProfile;
use App\Models\Owner;
use App\Models\Pet;
use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function admin(): View
    {
        return view('dashboards.admin', [
            'stats' => [
                'Propietarios' => Owner::count(),
                'Doctores' => DoctorProfile::whereHas('user', fn ($query) => $query->where('role', User::ROLE_DOCTOR))->count(),
                'Doctores pendientes' => DoctorProfile::where('approval_status', DoctorProfile::STATUS_PENDING)->count(),
                'Mascotas' => Pet::count(),
                'Citas próximas' => Appointment::whereIn('status', [Appointment::STATUS_PENDING, Appointment::STATUS_CONFIRMED])->where('scheduled_at', '>=', now())->count(),
            ],
            'pendingDoctors' => DoctorProfile::with('user')
                ->where('approval_status', DoctorProfile::STATUS_PENDING)
                ->whereHas('user', fn ($query) => $query->where('role', User::ROLE_DOCTOR))
                ->orderBy('created_at')->orderBy('id')->limit(5)->get(),
        ]);
    }

    public function doctor(Request $request): View
    {
        $doctor = $request->user()->doctorProfile;
        $appointments = $doctor->appointments()->whereIn('status', [Appointment::STATUS_PENDING, Appointment::STATUS_CONFIRMED]);

        return view('dashboards.doctor', [
            'stats' => [
                'Citas de hoy' => (clone $appointments)->whereDate('scheduled_at', today())->count(),
                'Próximas citas' => (clone $appointments)->where('scheduled_at', '>=', now())->count(),
                'Mascotas registradas' => Pet::count(),
                'Consultas recientes' => $doctor->consultations()->whereBetween('consulted_at', [now()->subDays(30), now()])->count(),
            ],
            'appointments' => (clone $appointments)->with('pet.owner', 'doctor.user')->where('scheduled_at', '>=', now())->orderBy('scheduled_at')->orderBy('id')->limit(5)->get(),
        ]);
    }

    public function owner(Request $request): View
    {
        $owner = $request->user()->owner;
        $pets = Pet::where('owner_id', $owner?->id ?? 0);
        $appointments = Appointment::whereHas('pet', fn ($query) => $query->where('owner_id', $owner?->id ?? 0))
            ->whereIn('status', [Appointment::STATUS_PENDING, Appointment::STATUS_CONFIRMED])->where('scheduled_at', '>=', now());
        $consultations = Consultation::whereHas('pet', fn ($query) => $query->where('owner_id', $owner?->id ?? 0));

        return view('dashboards.owner', [
            'stats' => ['Mis mascotas' => (clone $pets)->count(), 'Mis próximas citas' => (clone $appointments)->count(), 'Consultas en mi historial' => $consultations->count()],
            'pets' => $pets->with('species', 'breed')->orderBy('name')->orderBy('id')->limit(6)->get(),
            'appointments' => $appointments->with('pet', 'doctor.user')->orderBy('scheduled_at')->orderBy('id')->limit(5)->get(),
        ]);
    }
}
