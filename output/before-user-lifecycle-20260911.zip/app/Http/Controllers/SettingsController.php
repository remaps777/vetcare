<?php

namespace App\Http\Controllers;

use App\Models\ClinicSetting;
use App\Services\ConfirmedMutation;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function show(): View
    {
        $settings = ClinicSetting::firstOrCreate([], [
            'name' => 'VetCare',
            'appointment_minutes' => 30,
        ]);

        return view('admin.settings', compact('settings'));
    }

    public function update(Request $request, ConfirmedMutation $mutation): JsonResponse
    {
        $settings = ClinicSetting::firstOrFail();

        $data = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'phone' => ['nullable', 'string', 'max:30'],
            'email' => ['nullable', 'email', 'max:150'],
            'address' => ['nullable', 'string', 'max:255'],
            'appointment_minutes' => ['required', 'integer', 'in:15,20,30,45,60'],
        ]);

        return $mutation->handle(
            $request,
            $settings,
            $data,
            function ($locked, $values): ClinicSetting {
                $locked->fill($values)->save();

                return $locked;
            },
            [
                'Nombre de la clínica' => $data['name'],
                'Teléfono' => $data['phone'] ?? '—',
                'Correo' => $data['email'] ?? '—',
                'Dirección' => $data['address'] ?? '—',
                'Duración de citas (min)' => $data['appointment_minutes'],
            ],
            true, // sensitive — requires password + audit log
        );
    }
}
